<template>
  <div class="h-full flex flex-col overflow-hidden">
    <!-- 顶部操作栏 -->
    <div class="flex-shrink-0 p-6 border-b bg-white">
      <div class="flex items-center justify-between">
        <div>
          <h2 class="text-2xl font-bold text-gray-900 mb-2">样式管理中心</h2>
          <p class="text-gray-600">管理所有装饰样式模板：添加、编辑、删除</p>
        </div>

        <div class="flex items-center space-x-3">
          <button
            @click="handleImport"
            class="px-3 py-2 bg-green-100 hover:bg-green-200 text-green-700 text-sm font-medium rounded-lg transition-colors"
            title="导入自定义样式"
          >
            📥 导入
          </button>
          <button
            @click="handleExport"
            class="px-3 py-2 bg-purple-100 hover:bg-purple-200 text-purple-700 text-sm font-medium rounded-lg transition-colors"
            title="导出自定义样式"
          >
            📤 导出
          </button>
          <button
            @click="handleClearCustom"
            class="px-3 py-2 bg-red-100 hover:bg-red-200 text-red-700 text-sm font-medium rounded-lg transition-colors"
            title="清除所有自定义样式"
          >
            🗑️ 清除自定义
          </button>
          <button
            @click="goBack"
            class="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 font-medium rounded-lg transition-colors"
          >
            ← 返回编辑
          </button>
          <button
            @click="addNewStyle"
            class="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors flex items-center space-x-2"
          >
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path>
            </svg>
            <span>添加新样式</span>
          </button>
        </div>
      </div>
    </div>

    <!-- Tab 切换 -->
    <div class="flex-shrink-0 flex border-b bg-white">
      <button
        v-for="tab in tabs"
        :key="tab.value"
        @click="activeTab = tab.value"
        :class="[
          'flex-1 px-6 py-3 text-sm font-medium transition-colors',
          activeTab === tab.value
            ? 'text-blue-600 border-b-2 border-blue-600 bg-blue-50'
            : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
        ]"
      >
        {{ tab.label }} ({{ getStyleCount(tab.value) }})
      </button>
    </div>

    <!-- 样式列表 -->
    <div class="flex-1 overflow-y-auto p-6">
      <div class="grid grid-cols-3 gap-4">
        <div
          v-for="style in currentStyles"
          :key="style.id"
          class="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-all"
        >
          <!-- 样式预览 -->
          <div class="h-24 overflow-hidden rounded bg-gray-50 mb-3 flex items-center justify-center">
            <div v-html="style.preview" class="transform scale-90"></div>
          </div>

          <!-- 样式信息 -->
          <div class="mb-3">
            <div class="flex items-center justify-between mb-1">
              <h3 class="font-medium text-gray-900">{{ style.name }}</h3>
              <span v-if="isCustomStyle(style.id)" class="px-2 py-0.5 bg-blue-100 text-blue-700 text-xs font-medium rounded">
                自定义
              </span>
            </div>
            <p class="text-xs text-gray-500">ID: {{ style.id }}</p>
          </div>

          <!-- 操作按钮 -->
          <div class="flex space-x-2">
            <button
              @click="editStyle(style)"
              :disabled="!isCustomStyle(style.id)"
              :class="[
                'flex-1 px-3 py-1.5 text-sm font-medium rounded transition-colors',
                isCustomStyle(style.id)
                  ? 'bg-blue-100 hover:bg-blue-200 text-blue-700'
                  : 'bg-gray-100 text-gray-400 cursor-not-allowed'
              ]"
              :title="isCustomStyle(style.id) ? '编辑' : '默认样式不可编辑'"
            >
              编辑
            </button>
            <button
              @click="deleteStyleHandler(style)"
              :disabled="!isCustomStyle(style.id)"
              :class="[
                'flex-1 px-3 py-1.5 text-sm font-medium rounded transition-colors',
                isCustomStyle(style.id)
                  ? 'bg-red-100 hover:bg-red-200 text-red-700'
                  : 'bg-gray-100 text-gray-400 cursor-not-allowed'
              ]"
              :title="isCustomStyle(style.id) ? '删除' : '默认样式不可删除'"
            >
              删除
            </button>
          </div>
        </div>
      </div>

      <!-- 空状态 -->
      <div v-if="currentStyles.length === 0" class="text-center py-12">
        <div class="text-gray-400 text-lg mb-2">暂无样式</div>
        <button
          @click="addNewStyle"
          class="mt-4 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors"
        >
          添加第一个样式
        </button>
      </div>
    </div>

    <!-- 编辑/添加样式对话框 -->
    <div
      v-if="showEditDialog"
      class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
      @click.self="closeEditDialog"
    >
      <div class="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div class="p-6">
          <h3 class="text-xl font-bold text-gray-900 mb-4">
            {{ editingStyle ? '编辑样式' : '添加新样式' }}
          </h3>

          <div class="space-y-4">
            <!-- 样式名称 -->
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">样式名称</label>
              <input
                v-model="editForm.name"
                type="text"
                class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                placeholder="例如：渐变标题"
              />
            </div>

            <!-- 样式类型 -->
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">样式类型</label>
              <select
                v-model="editForm.type"
                class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
              >
                <option value="title">标题</option>
                <option value="body">正文</option>
                <option value="intro">引言</option>
              </select>
            </div>

            <!-- 预览HTML -->
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">预览HTML（缩略图）</label>
              <textarea
                v-model="editForm.preview"
                rows="3"
                class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 font-mono text-sm"
                placeholder="用于缩略图显示的HTML代码"
              ></textarea>
            </div>

            <!-- 完整模板HTML -->
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">
                完整模板HTML（必须包含 {{CONTENT}} 占位符）
              </label>
              <textarea
                v-model="editForm.fullExample"
                rows="8"
                class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 font-mono text-sm"
                placeholder="完整的HTML模板，用 {{CONTENT}} 作为内容占位符"
              ></textarea>
            </div>

            <!-- 预览区域 -->
            <div v-if="editForm.preview">
              <label class="block text-sm font-medium text-gray-700 mb-1">实时预览</label>
              <div class="border border-gray-200 rounded-lg p-4 bg-gray-50">
                <div v-html="editForm.preview"></div>
              </div>
            </div>
          </div>

          <!-- 对话框按钮 -->
          <div class="flex justify-end space-x-3 mt-6">
            <button
              @click="closeEditDialog"
              class="px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 font-medium rounded-lg transition-colors"
            >
              取消
            </button>
            <button
              @click="saveStyle"
              class="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors"
            >
              保存
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import {
  getAllStyles,
  addCustomStyle,
  updateStyle,
  deleteStyle,
  isCustomStyle,
  exportCustomStyles,
  importCustomStyles,
  clearCustomStyles
} from '../styles/styleStorage.js'

const router = useRouter()

// Tab 配置
const tabs = [
  { value: 'title', label: '标题样式' },
  { value: 'body', label: '正文样式' },
  { value: 'intro', label: '引言样式' }
]

// 当前激活的 Tab
const activeTab = ref('title')

// 样式数据（默认 + 自定义）
const allStyles = ref({ title: [], body: [], intro: [] })

// 加载所有样式
const loadStyles = () => {
  allStyles.value = getAllStyles()
}

// 当前显示的样式列表
const currentStyles = computed(() => {
  return allStyles.value[activeTab.value] || []
})

// 获取样式数量
const getStyleCount = (type) => {
  return allStyles.value[type]?.length || 0
}

// 编辑对话框状态
const showEditDialog = ref(false)
const editingStyle = ref(null)
const editForm = ref({
  name: '',
  type: 'title',
  preview: '',
  fullExample: ''
})

// 添加新样式
const addNewStyle = () => {
  editingStyle.value = null
  editForm.value = {
    name: '',
    type: activeTab.value,
    preview: '',
    fullExample: ''
  }
  showEditDialog.value = true
}

// 编辑样式
const editStyle = (style) => {
  editingStyle.value = style
  editForm.value = {
    name: style.name,
    type: style.type,
    preview: style.preview,
    fullExample: style.fullExample
  }
  showEditDialog.value = true
}

// 保存样式
const saveStyle = () => {
  if (!editForm.value.name || !editForm.value.fullExample) {
    alert('请填写样式名称和完整模板HTML')
    return
  }

  if (!editForm.value.fullExample.includes('{{CONTENT}}')) {
    alert('完整模板HTML必须包含 {{CONTENT}} 占位符')
    return
  }

  if (editingStyle.value) {
    // 编辑现有样式
    if (!isCustomStyle(editingStyle.value.id)) {
      alert('默认样式不可编辑，只能编辑自定义样式')
      return
    }
    
    const success = updateStyle(editingStyle.value.id, {
      name: editForm.value.name,
      type: editForm.value.type,
      preview: editForm.value.preview,
      fullExample: editForm.value.fullExample
    })
    
    if (success) {
      loadStyles()
      closeEditDialog()
      alert('保存成功！')
    } else {
      alert('保存失败，请重试')
    }
  } else {
    // 添加新样式
    const newStyle = addCustomStyle({
      name: editForm.value.name,
      type: editForm.value.type,
      preview: editForm.value.preview,
      fullExample: editForm.value.fullExample
    })
    
    if (newStyle) {
      loadStyles()
      closeEditDialog()
      alert('添加成功！')
    } else {
      alert('添加失败，请重试')
    }
  }
}

// 删除样式
const deleteStyleHandler = (style) => {
  if (!isCustomStyle(style.id)) {
    alert('默认样式不可删除，只能删除自定义样式')
    return
  }
  
  if (confirm(`确定要删除样式"${style.name}"吗？此操作不可恢复。`)) {
    const success = deleteStyle(style.id)
    if (success) {
      loadStyles()
      alert('删除成功！')
    } else {
      alert('删除失败，请重试')
    }
  }
}

// 导出自定义样式
const handleExport = () => {
  exportCustomStyles()
  alert('导出成功！文件已下载')
}

// 导入自定义样式
const handleImport = () => {
  const input = document.createElement('input')
  input.type = 'file'
  input.accept = '.json'
  
  input.onchange = async (e) => {
    const file = e.target.files[0]
    if (!file) return
    
    try {
      await importCustomStyles(file)
      loadStyles()
      alert('导入成功！')
    } catch (error) {
      alert(`导入失败：${error.message}`)
    }
  }
  
  input.click()
}

// 清除所有自定义样式
const handleClearCustom = () => {
  if (confirm('确定要清除所有自定义样式吗？此操作不可恢复。')) {
    const success = clearCustomStyles()
    if (success) {
      loadStyles()
      alert('清除成功！')
    } else {
      alert('清除失败，请重试')
    }
  }
}

// 关闭编辑对话框
const closeEditDialog = () => {
  showEditDialog.value = false
  editingStyle.value = null
}

// 返回编辑页面
const goBack = () => {
  router.push('/step2')
}

// 组件挂载时加载样式
onMounted(() => {
  loadStyles()
})
</script>

<style scoped>
/* 组件特定样式 */
</style>