/**
 * 共享的样式模板数据
 * 供 StyleConfig 和 StyleSelector 组件使用
 * 包含高仿 135编辑器/SVG 风格的高级样式
 */

// 标题装饰样式数据
export const titleDecorations = [
  {
    id: 'title_mac',
    name: 'Mac窗口标题',
    type: 'title',
    preview: `<div style="background: #f0f0f0; border-radius: 6px; padding: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);">
      <div style="display: flex; gap: 4px; margin-bottom: 6px;">
        <div style="width: 8px; height: 8px; border-radius: 50%; background: #ff5f56;"></div>
        <div style="width: 8px; height: 8px; border-radius: 50%; background: #ffbd2e;"></div>
        <div style="width: 8px; height: 8px; border-radius: 50%; background: #27c93f;"></div>
      </div>
      <div style="height: 4px; background: #ddd; border-radius: 2px; width: 60%;"></div>
    </div>`,
    fullExample: `<section class="_135editor" data-role="paragraph" style="margin: 20px 0;">
      <section style="background: #f8f9fa; border: 1px solid #e9ecef; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); overflow: hidden;">
        <section style="background: #e9ecef; padding: 10px 15px; display: flex; align-items: center; border-bottom: 1px solid #dee2e6;">
          <div style="width: 12px; height: 12px; border-radius: 50%; background: #ff5f56; margin-right: 8px;"></div>
          <div style="width: 12px; height: 12px; border-radius: 50%; background: #ffbd2e; margin-right: 8px;"></div>
          <div style="width: 12px; height: 12px; border-radius: 50%; background: #27c93f;"></div>
        </section>
        <section style="padding: 20px;">
          <p style="margin: 0; font-size: 16px; line-height: 1.75em; text-align: center; font-weight: bold; color: #333;">
            {{CONTENT}}
          </p>
        </section>
      </section>
    </section>`
  },
  {
    id: 'title_ins_simple',
    name: 'INS风极简',
    type: 'title',
    preview: `<div style="text-align: center; padding: 8px;">
      <span style="display: inline-block; border-bottom: 1px solid #333; padding-bottom: 2px; font-size: 12px;">INS STYLE</span>
    </div>`,
    fullExample: `<section class="_135editor" data-role="paragraph" style="margin: 30px 0; text-align: center;">
      <section style="display: inline-block; position: relative; padding: 0 10px;">
        <span style="display: block; font-size: 12px; color: #999; letter-spacing: 4px; margin-bottom: 5px;">TITLE</span>
        <span style="display: block; font-size: 18px; color: #333; font-weight: bold; letter-spacing: 2px; border-bottom: 1px solid #333; padding-bottom: 8px;">{{CONTENT}}</span>
      </section>
    </section>`
  },
  {
    id: 'title_gradient_tag',
    name: '渐变标签',
    type: 'title',
    preview: `<div style="padding: 8px;">
      <span style="background: linear-gradient(90deg, #ff9a9e 0%, #fecfef 100%); color: white; padding: 2px 8px; border-radius: 10px 0 10px 0; font-size: 10px;">New</span>
    </div>`,
    fullExample: `<section class="_135editor" data-role="paragraph" style="margin: 20px 0;">
      <section style="display: inline-block; background: linear-gradient(90deg, #ff9a9e 0%, #fecfef 99%, #fecfef 100%); border-radius: 20px 0 20px 0; padding: 5px 20px; box-shadow: 2px 2px 5px rgba(255, 154, 158, 0.4);">
        <p style="margin: 0; font-size: 16px; color: #fff; font-weight: bold; letter-spacing: 1px;">{{CONTENT}}</p>
      </section>
    </section>`
  },
  {
    id: 'title_tech_neon',
    name: '赛博霓虹',
    type: 'title',
    preview: `<div style="background: #111; padding: 8px; text-align: center;">
      <span style="color: #0ff; text-shadow: 0 0 5px #0ff; font-size: 12px;">CYBER</span>
    </div>`,
    fullExample: `<section class="_135editor" data-role="paragraph" style="margin: 20px 0; background: #000; padding: 15px; border: 1px solid #0ff; box-shadow: 0 0 10px rgba(0, 255, 255, 0.5); text-align: center;">
      <p style="margin: 0; font-size: 18px; font-weight: bold; color: #fff; text-shadow: 2px 2px 0 #f0f, -1px -1px 0 #0ff;">
        {{CONTENT}}
      </p>
    </section>`
  },
  {
    id: 'title_chinese_ink',
    name: '水墨中国风',
    type: 'title',
    preview: `<div style="text-align: center; padding: 8px;">
      <div style="border: 1px solid #333; width: 20px; height: 20px; transform: rotate(45deg); display: inline-block;"></div>
    </div>`,
    fullExample: `<section class="_135editor" data-role="paragraph" style="margin: 30px 0; text-align: center;">
      <section style="display: flex; align-items: center; justify-content: center;">
        <section style="width: 40px; height: 1px; background: #333;"></section>
        <section style="margin: 0 15px; border: 1px solid #333; padding: 5px; transform: rotate(45deg);">
          <div style="width: 100%; height: 100%; background: #333; transform: scale(0.8);"></div>
        </section>
        <section style="width: 40px; height: 1px; background: #333;"></section>
      </section>
      <p style="margin-top: 15px; font-size: 18px; font-weight: bold; color: #333; font-family: 'STKaiti', 'KaiTi', serif;">{{CONTENT}}</p>
    </section>`
  },
  {
    id: 'title_number_circle',
    name: '序号圆点',
    type: 'title',
    preview: `<div style="display: flex; align-items: center; padding: 8px;">
      <div style="width: 16px; height: 16px; background: #6c5ce7; border-radius: 50%; color: white; font-size: 10px; text-align: center; line-height: 16px;">1</div>
      <div style="width: 30px; height: 1px; background: #6c5ce7; margin-left: 4px;"></div>
    </div>`,
    fullExample: `<section class="_135editor" data-role="paragraph" style="margin: 20px 0;">
      <section style="display: flex; align-items: center;">
        <section style="width: 30px; height: 30px; background: #6c5ce7; border-radius: 50%; color: white; font-size: 16px; font-weight: bold; text-align: center; line-height: 30px; flex-shrink: 0; box-shadow: 0 2px 5px rgba(108, 92, 231, 0.4);">01</section>
        <section style="flex: 1; margin-left: 10px; border-bottom: 2px dashed #a29bfe; padding-bottom: 5px;">
          <p style="margin: 0; font-size: 18px; font-weight: bold; color: #6c5ce7;">{{CONTENT}}</p>
        </section>
      </section>
    </section>`
  }
]

// 正文装饰样式数据
export const bodyDecorations = [
  {
    id: 'body_mac_window',
    name: 'Mac代码窗',
    type: 'body',
    preview: `<div style="background: #282c34; border-radius: 4px; padding: 6px;">
      <div style="display: flex; gap: 2px; margin-bottom: 4px;">
        <div style="width: 4px; height: 4px; border-radius: 50%; background: #ff5f56;"></div>
        <div style="width: 4px; height: 4px; border-radius: 50%; background: #ffbd2e;"></div>
        <div style="width: 4px; height: 4px; border-radius: 50%; background: #27c93f;"></div>
      </div>
      <div style="height: 2px; background: #3e4451; width: 80%;"></div>
    </div>`,
    fullExample: `<section class="_135editor" data-role="paragraph" style="margin: 20px 0;">
      <section style="background: #282c34; border-radius: 8px; box-shadow: 0 10px 30px rgba(0,0,0,0.3); overflow: hidden;">
        <section style="background: #21252b; padding: 10px 15px; display: flex; align-items: center;">
          <div style="width: 12px; height: 12px; border-radius: 50%; background: #ff5f56; margin-right: 8px;"></div>
          <div style="width: 12px; height: 12px; border-radius: 50%; background: #ffbd2e; margin-right: 8px;"></div>
          <div style="width: 12px; height: 12px; border-radius: 50%; background: #27c93f;"></div>
        </section>
        <section style="padding: 20px; color: #abb2bf; font-family: Consolas, Monaco, 'Andale Mono', 'Ubuntu Mono', monospace; font-size: 14px; line-height: 1.6;">
          <p style="margin: 0;">{{CONTENT}}</p>
        </section>
      </section>
    </section>`
  },
  {
    id: 'body_ins_card',
    name: 'INS风卡片',
    type: 'body',
    preview: `<div style="background: #fff; border-radius: 8px; padding: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.08);">
      <div style="height: 4px; background: #f0f0f0; border-radius: 2px;"></div>
    </div>`,
    fullExample: `<section class="_135editor" data-role="paragraph" style="margin: 20px 0; padding: 20px; background: #ffffff; border-radius: 12px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); border: 1px solid #f0f0f0;">
      <section style="display: flex; align-items: center; margin-bottom: 15px;">
        <div style="width: 8px; height: 8px; background: #ff9a9e; border-radius: 50%;"></div>
        <div style="height: 1px; background: #eee; flex: 1; margin-left: 10px;"></div>
      </section>
      <p style="margin: 0; font-size: 15px; line-height: 1.8; color: #555; text-align: justify;">
        {{CONTENT}}
      </p>
      <section style="display: flex; align-items: center; margin-top: 15px;">
        <div style="height: 1px; background: #eee; flex: 1; margin-right: 10px;"></div>
        <div style="width: 8px; height: 8px; background: #a18cd1; border-radius: 50%;"></div>
      </section>
    </section>`
  },
  {
    id: 'body_paper_note',
    name: '复古纸条',
    type: 'body',
    preview: `<div style="background: #fff8e1; border: 1px solid #ffe082; padding: 6px; transform: rotate(-2deg);">
      <div style="height: 2px; background: #ffe082; width: 100%;"></div>
    </div>`,
    fullExample: `<section class="_135editor" data-role="paragraph" style="margin: 25px 0;">
      <section style="background: #fff8e1; padding: 20px; border: 1px solid #ffe082; box-shadow: 2px 2px 0 rgba(0,0,0,0.1); transform: rotate(-1deg); position: relative;">
        <div style="position: absolute; top: -8px; left: 50%; transform: translateX(-50%); width: 40px; height: 15px; background: rgba(255,255,255,0.5); transform: rotate(2deg);"></div>
        <p style="margin: 0; font-size: 15px; line-height: 1.8; color: #5d4037; text-align: justify;">
          {{CONTENT}}
        </p>
      </section>
    </section>`
  },
  {
    id: 'body_dashed_box',
    name: '虚线边框',
    type: 'body',
    preview: `<div style="border: 1px dashed #ff7675; border-radius: 4px; padding: 6px;">
      <div style="height: 4px; background: #ffeaa7; width: 50%;"></div>
    </div>`,
    fullExample: `<section class="_135editor" data-role="paragraph" style="margin: 20px 0; padding: 2px; background: linear-gradient(to right, #ff7675, #fd79a8); border-radius: 12px;">
      <section style="background: #fff; padding: 20px; border-radius: 10px; border: 1px dashed #ff7675;">
        <p style="margin: 0; font-size: 15px; line-height: 1.8; color: #333; text-align: justify;">
          {{CONTENT}}
        </p>
      </section>
    </section>`
  }
]

// 引言装饰样式数据
export const introDecorations = [
  {
    id: 'intro_quote_big',
    name: '大引号',
    type: 'intro',
    preview: `<div style="text-align: center; font-size: 20px; color: #ddd; font-weight: bold;">“ ”</div>`,
    fullExample: `<section class="_135editor" data-role="paragraph" style="margin: 30px 0; text-align: center;">
      <span style="font-size: 60px; color: #f0f0f0; font-family: Arial, sans-serif; line-height: 0.5; display: block;">“</span>
      <p style="margin: -20px 20px 0; font-size: 14px; line-height: 1.8; color: #888; font-style: italic;">
        {{CONTENT}}
      </p>
      <span style="font-size: 60px; color: #f0f0f0; font-family: Arial, sans-serif; line-height: 0.5; display: block; margin-top: 10px;">”</span>
    </section>`
  },
  {
    id: 'intro_vertical_line',
    name: '竖线引言',
    type: 'intro',
    preview: `<div style="border-left: 2px solid #0984e3; padding-left: 6px; font-size: 10px; color: #666;">引言内容...</div>`,
    fullExample: `<section class="_135editor" data-role="paragraph" style="margin: 20px 0; background: #f1f2f6; border-left: 5px solid #0984e3; padding: 15px 20px;">
      <p style="margin: 0; font-size: 15px; line-height: 1.6; color: #2d3436; font-weight: 500;">
        {{CONTENT}}
      </p>
    </section>`
  },
  {
    id: 'intro_gradient_bg',
    name: '渐变背景',
    type: 'intro',
    preview: `<div style="background: linear-gradient(120deg, #84fab0 0%, #8fd3f4 100%); padding: 6px; border-radius: 4px;"></div>`,
    fullExample: `<section class="_135editor" data-role="paragraph" style="margin: 20px 0; background: linear-gradient(120deg, #84fab0 0%, #8fd3f4 100%); padding: 25px; border-radius: 8px; color: #fff; box-shadow: 0 5px 15px rgba(132, 250, 176, 0.3);">
      <p style="margin: 0; font-size: 15px; line-height: 1.8; text-align: justify; font-weight: 500; text-shadow: 0 1px 2px rgba(0,0,0,0.1);">
        {{CONTENT}}
      </p>
    </section>`
  }
]
